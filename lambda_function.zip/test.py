#!/usr/bin/python
from time import time
from pytube import YouTube


times=[]
for i in range(10):
    start = time()
    yt=YouTube("https://www.youtube.com/watch?v=p6tsjw737BA")
    times.append(time()-start)
print times
print sum(times) / len(times)

# original 4.16s
# with session 4.07s
# with threading 3.59s
